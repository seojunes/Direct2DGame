#include "TMissile.h"
#include "TDevice.h"

std::vector<std::shared_ptr<TMissileState>>  TMissileObj::m_pMActionList;

void    TMissileObj::HitOverlap(TObject* pObj, THitResult hRes)
{
	//m_bDead = true;
}

void TMissileObj::Frame()
{
	TVector2 vAdd = m_vPos;
	//������� ���ǵ� EVENT�� ���� �� ���￹��.
	if (m_vPos.x > m_pHero->m_rtScreen.v2.x + 600 || m_vPos.x < m_pHero->m_rtScreen.v1.x - 600)
	{
  		m_bDead = true;
	}
	//�̵��� EVNET�� ����
	m_vPos = vAdd + m_vDir * (g_fSPF * m_fSpeed);
	SetPosition(m_vPos);

}

void TMissileObj::SetDirrection(HeroView view)
{
	if (view == HeroView::RightView)
		m_vDir.x = 1; // ������
	else if (view == HeroView::LeftView)
		m_vDir.x = -1; // ����
}

void TMissileObj::SetVertexData()
{
	if (m_pTexture == nullptr) return;
	TObject2D::SetVertexData();
	float xSize = m_pTexture->m_TexDesc.Width;
	float ySize = m_pTexture->m_TexDesc.Height;
	TRect rt;
	rt.SetS(0.0f, 19.0f, 14.0f, 29.0f);
	if (m_vDir.x == 1)
	{
 		m_vVertexList[0].t = { rt.v1.x / xSize,rt.v1.y / ySize };
		m_vVertexList[1].t = { rt.v2.x / xSize,rt.v1.y / ySize };
		m_vVertexList[2].t = { rt.v1.x / xSize,rt.vs.y / ySize };
		m_vVertexList[3].t = { rt.v2.x / xSize,rt.vs.y / ySize };
	}	
	else if (m_vDir.x == -1)
	{
		m_vVertexList[0].t = { rt.v2.x / xSize,rt.v1.y / ySize };
		m_vVertexList[1].t = { rt.v1.x / xSize,rt.v1.y / ySize };
		m_vVertexList[2].t = { rt.v2.x / xSize,rt.vs.y / ySize };
		m_vVertexList[3].t = { rt.v1.x / xSize,rt.vs.y / ySize };
	}
	
}

void TMissileObj::SetFSM(TFiniteStateMachine* pFsm)
{
	//  STATE_IDLE = 0,        // ��� ���� (�߻� ���)
	//	STATE_SHOT,            // �߻� ����
	//	STATE_FLYING,          // ���� ��
	//	STATE_HIT,             // ��ǥ�� Ÿ��
	//	STATE_EXPLODE,         // ���� ����
	//	STATE_DESTROY,		   // �Ҹ� ����
	//	STATE_MISSILE_COUNTER,
	m_pMFsm = pFsm;
	m_MStateData.resize(T_MissileState::STATE_MISSILE_COUNTER);
	m_MStateData[T_MissileState::STATE_IDLE].m_fTimer = 3.0f;
	m_MStateData[T_MissileState::STATE_SHOT].m_fTimer = 3.0f;
	m_MStateData[T_MissileState::STATE_FLYING].m_fTimer = 3.0f;
	m_MStateData[T_MissileState::STATE_HIT].m_fTimer = 3.0f;
	m_MStateData[T_MissileState::STATE_EXPLODE].m_fTimer = 3.0f;
	m_MStateData[T_MissileState::STATE_DESTROY].m_fTimer = 3.0f;
	m_pMAction = m_pMActionList[0].get();
}
void TMissileObj::StartFSM()
{
	if (m_pMActionList.size()) return;
	std::shared_ptr<TMissileState> idle = std::make_shared<TIdleAction>();
	std::shared_ptr<TMissileState> shot =	std::make_shared<TShotAction>();
	std::shared_ptr<TMissileState> fly = std::make_shared<TFlyingAction>();
	std::shared_ptr<TMissileState> hit =  std::make_shared<THitAction>();
	std::shared_ptr<TMissileState> explode=   std::make_shared<TExplodeAction>();
	std::shared_ptr<TMissileState> destory = std::make_shared<TDestroyAction>();
	m_pMActionList.emplace_back(idle);
	m_pMActionList.emplace_back(shot);
	m_pMActionList.emplace_back(fly);
	m_pMActionList.emplace_back(hit);
	m_pMActionList.emplace_back(explode);
	m_pMActionList.emplace_back(destory);
}
void TMissileObj::SetTransition(UINT iEvent)
{
	_ASSERT(m_pMFsm);
	UINT iOutput = m_pMFsm->GetOutputState(	m_pMAction->m_iMissileState, iEvent);
	m_pMAction = m_pMActionList[iOutput].get();
}
void TMissileObj::FrameState(TObject* pNpc)
{
	m_pMAction->m_pOwner = this;
	m_pMAction->ProcessAction(pNpc);
}