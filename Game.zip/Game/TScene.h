#pragma once
class TScene
{
};

