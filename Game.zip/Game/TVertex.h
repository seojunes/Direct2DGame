#pragma once
#include "TVector.h"
struct P_VERTEX
{
	TVector2 v;
};
struct PC_VERTEX
{
	TVector2 v;
	TVector4 c;
};
struct PCT_VERTEX
{
	TVector2 v;
	TVector4 c;
	TVector2 t;
};

