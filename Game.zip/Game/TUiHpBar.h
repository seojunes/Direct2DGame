#include "TControlGUI.h"
#include "TMapObj.h"
#include "THeroObj.h"
#include "TBossObj.h"
#pragma once

enum HPBAR_OWNER
{
	BAROWNER_HERO = 0,
	BAROWNER_BOSS,
};

class TUiHpBar :public TImageGUI
{
	THeroObj* m_pHero = nullptr;
	TBossObj* m_pBoss = nullptr;
public:
	void SetHero(THeroObj* pHero) { m_pHero = pHero; }
	void SetBoss(TBossObj* pBoss) { m_pBoss = pBoss; }
	void SetHeroHp(INT hp);
	void SetBossHp(INT hp);
public:
	INT m_iHP;
	INT m_iMaxHp;
	float m_fHpRatio = 1.0f;
	TVector2 m_vInitialScale; // �ʱ� ũ�� ����
public:
	INT m_iBHP;
	INT m_iBMaxHp;
	float m_fBHpRatio = 1.0f;
	TVector2 m_vBInitialScale; // �ʱ� ũ�� ����
public:
	HPBAR_OWNER m_eBarOwner = HPBAR_OWNER::BAROWNER_HERO;
public:
	void Frame() override;
	//void Render() override;
public:
	TUiHpBar(HPBAR_OWNER owner)
	{
		m_eBarOwner = owner;
	}
};

class TUIHpTile : public TImageGUI
{
	
};

