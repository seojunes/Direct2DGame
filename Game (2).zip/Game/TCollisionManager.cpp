#include "TCollisionManager.h"
#include "TDevice.h"

void    TCollisionManager::HitOverlap(TObject* pObj, THitResult hRes)
{

}

//vector<TVector2> TCollisionManager::MakeSBox()
//{
//	rectSList.emplace_back(m_vStart);
//	return rectSList;
//}
//vector<TVector2> TCollisionManager::MakeEBox() 
//{
//	rectEList.emplace_back(m_vEnd);
//	return rectEList;
//}

