#include "TScene.h"
TScene::TScene(TGame* p) : m_pOwner(p)
{

}
TScene::TScene()
{
};
TScene::~TScene()
{

}