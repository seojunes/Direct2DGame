//#include "THeroFSM.h"
//#include "THeroObj.h"
//
//THeroState::THeroState(THeroObj* p) : m_pOwner(p) {
//
//}
//THeroState::~THeroState() {}
//
//TIdleAction::TIdleAction(THeroObj* p) : THeroState(p)
//{
//	m_iHeroState = 0;
//}
//TIdleAction::TIdleAction(THeroObj* p) : THeroState(p)
//{
//	m_iHeroState = 1;
//}
//TUpperAction::~TUpperAction() {}
//TLowerAction::TLowerAction(THeroObj* p) : THeroState(p) 
//{
//	m_iHeroState = 2;
//}
//TLowerAction::~TLowerAction() {}
//TRightAction::TRightAction(THeroObj* p) : THeroState(p) 
//{
//	m_iHeroState = 3;
//}
//TRightAction::~TRightAction() {}
//TLeftAction::TLeftAction(THeroObj* p) : THeroState(p) 
//{
//	m_iHeroState = 4;
//}
//TLeftAction::~TLeftAction() {}
//
//
//void TUpperAction::ProcessAction(TObject* pObj)
//{
//	m_pOwner->m_rtScreen.v1.x
//}
//
//
//void TLowerAction::ProcessAction(TObject* pObj)
//{
//
//}
//
//
//void TRightAction::ProcessAction(TObject* pObj)
//{
//
//}
//
//
//void TLeftAction::ProcessAction(TObject* pObj)
//{
//
//}
