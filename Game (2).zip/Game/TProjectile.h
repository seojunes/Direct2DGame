#pragma once
class TProjectile
{
};

